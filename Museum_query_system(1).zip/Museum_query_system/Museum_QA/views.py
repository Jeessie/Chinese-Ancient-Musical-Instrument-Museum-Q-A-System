from django.shortcuts import render
from django.http import HttpResponse
import sys
from Museum_QA.code import main
# from django.contrib.auth.models import User
from django.contrib.auth import  authenticate,login,logout
from django.conf.urls import url
from django.contrib import admin
from django.shortcuts import render,HttpResponse,redirect
from Museum_QA.code import dict1
import json

# print(main.get_img("夏莲居和哪个展品有关"))

# 返回多个图片
def get_detail(request):
    context = {}
    str=""
    if request.POST:
        question = request.POST['ask']
        answer=main.query_function(question)
        for i in range(0,len(answer)):
            str+=answer[i]+" "
        context['rlt']=str
        context['pic'] = main.get_img(question)
        context['museum']=main.get_museum_img(question)
        # pic=main.get_img(question)
        # html = "<span>It is now %s.</span>"
    return render(request, 'project.html',context)
# 首页
def index(request):
    return render(request, "index.html")
# 增删改查界面
# def admin_add(request):
#     # return render(request,"test.html")
# 管理员登录
def admin(request):
    if request.method == 'POST':
        user = request.POST.get('name')
        pwd = request.POST.get('password')
        # 校验
        if user == 'Cathy' and pwd == 'gyfsb':
            # url重定向
            return redirect("../admin1/")
        elif user == 'Jessie' and pwd == 'vivo50':
            return redirect("../admin1/")
        elif user=='Odella' and pwd=='v587':
            return redirect("../admin1/")
    return render(request, 'login.html')
#增删改查
def manage(request):
	#context = {}
	result=dict1.searchall()
	if request.POST:
		if 'search' in request.POST:
			value = request.POST['search']
			result=dict1.findsearch(value)
		#print(question)
		#result=main.query_function(question)
		#result=dict1.query_graph("MATCH(p:Exhibits{名称:'"+value+"'})-[rel]->(n) RETURN rel")
		if 'searchall' in request.POST:
			result=dict1.searchall()
		#print(question)
		#result=main.query_function(question)
		#result=dict1.query_graph("MATCH(p:Exhibits{名称:'"+value+"'})-[rel]->(n) RETURN rel")
		if 'Addone' in request.POST:
			kind = request.POST.get("labels")
			value=request.POST['Addone']
			result=dict1.addonenode(kind,value)
		if "Addrel" in request.POST:
			kind1=request.POST.get("labels1")
			kind2=request.POST.get("labels2")
			value = request.POST['Addrel']
			result=dict1.Addrelationship(kind1,value,kind2)
		if 'deletenode' in request.POST:
			#kind2=request.POST.get("labels2")
			value = request.POST['deletenode']
			dict1.deletenode(value)
			result = dict1.query_graph("MATCH (n)-[rel]->(m)  RETURN rel")
		if 'deleteall' in request.POST:
			#kind2=request.POST.get("labels2")
			value = request.POST['deleteall']
			dict1.deleteall(value)
			result = dict1.query_graph("MATCH (n)-[rel]->(m)  RETURN rel")
			#return render(request, 'test.html', {'data': json.dumps(result['data']), 'link': json.dumps(result['links'])
		#result = dict1.query_graph("MATCH(p:Exhibits{名称:'" + value + "'})-[rel]->(n) RETURN rel")
		#result=dict1.query_graph("MATCH(p:Person{人物:'夏莲居'})-[rel]->(n:Exhibits{名称:'混沌材琴'}) RETURN rel")

	return render(request, 'test.html',{'data': json.dumps(result['data']), 'link': json.dumps(result['links'])})



    # return HttpResponse("Hello, world. You're at the query index.")
# Create your views here.
