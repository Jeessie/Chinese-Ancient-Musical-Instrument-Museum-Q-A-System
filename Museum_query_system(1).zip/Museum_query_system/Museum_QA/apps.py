from django.apps import AppConfig


class MuseumQaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Museum_QA'
