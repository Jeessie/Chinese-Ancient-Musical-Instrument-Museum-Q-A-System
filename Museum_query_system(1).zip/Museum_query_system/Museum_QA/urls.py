from django.urls import path
from django.urls import include,path
import views

urlpatterns = [
    path('', views.index, name='index'),
    path('query/',views.get_detail,name='query'),
    path('admin/',views.admin,name='admin'),
    path('admin1/',views.manage,name='add')
]